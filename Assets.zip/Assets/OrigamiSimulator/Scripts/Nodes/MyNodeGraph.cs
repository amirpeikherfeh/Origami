using UnityEngine;
using XNode;

[CreateAssetMenu(fileName = "New Origami Graph", menuName = "Origami/Origami Node Graph")]
public class MyNodeGraph : NodeGraph
{
    // You can add extra metadata here if needed
}
